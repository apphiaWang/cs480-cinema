package cs4280;

/**
 *
 * @author jsvollmer2
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Controller extends HttpServlet {

    private User userBean;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        
        if (action != null) {
            // call different action depends on the action parameter
            if (action.equalsIgnoreCase("details")) {
                this.doShowDetails(request, response);
            } else if (action.equalsIgnoreCase("seating")) {
                this.doShowSeat(request, response);
            } else if (action.equalsIgnoreCase("buying")) {
                this.doShowTicketsale(request, response);
            } else if (action.equalsIgnoreCase("buy")) {
                this.doBuy(request, response);
            }else if (action.equalsIgnoreCase("manageSeats")) {
                this.doManageSeats(request, response);
            } else if (action.equalsIgnoreCase("change")) {
                this.doChangeSeats(request, response);
            } else if (action.equalsIgnoreCase("manageSeat")) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/manageSeats.jsp");
                dispatcher.forward(request, response);
            } else if(action.equalsIgnoreCase("logout")){
                request.getSession().setAttribute("user", null);
                //request.getSession().setAttribute("cargo_full",null);
                this.doRetrieveEntry(request, response);
            }
        } else {
            this.doRetrieveEntry(request, response);
        }
    }

    private void doRetrieveEntry(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "/WEB-INF/MovieIndex.jsp";
        List<MovieDetail> movies = new ArrayList();
        MovieLookup.MoviesCreate();
        
        for (int i = 1; i <= MovieLookup.length; i++) {
            if (MovieLookup.getMovie(Integer.toString(i)) != null) {
                MovieDetail movie = MovieLookup.getMovie(Integer.toString(i));
                movies.add(movie);
            }
        }
        request.setAttribute("movies", movies);
          
        if(request.getSession().getAttribute("user")==null){
          
            userBean = new User();

            //set user 
            request.getSession().setAttribute("user", userBean);
        }
        if(request.getSession().getAttribute("cargo_full")==null){
          request.getSession().setAttribute("cargo_full",false);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }

    private void doManageSeats(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String address = "/WEB-INF/MovieSeat.jsp";
        String venue = request.getParameter("venue");
        String seating;
        String[] taken = {""};
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db", "aiad039", "aiad039");
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("SELECT [Seats] FROM [venue] WHERE [Venue] ='" + venue + "'");

            while (rs != null && rs.next() != false) {

                seating = rs.getString("Seats");
                if (seating != null) {
                    taken = seating.split(" ");
                }
            }

            if (rs != null) {
                rs.close();
            }
            con.close();
        } catch (ClassNotFoundException e) {
        } catch (SQLException e) {
        }
        List<Seat> seats = new ArrayList();
        for (int i = 1; i <= 16; i++) {
            String seatid = Integer.toString(i);
            String value = "";
            if (Arrays.asList(taken).contains(seatid)) {
                value = "unavailable";
            }
            Seat seat = new Seat(seatid, value);
            seats.add(seat);}
            request.setAttribute("seats", seats);
            request.setAttribute("venue", venue);
            RequestDispatcher dispatcher = request.getRequestDispatcher(address);
            dispatcher.forward(request, response);
        
    }

    private void doChangeSeats(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "";
        String seats[] = request.getParameterValues("seat");
        String venue = request.getParameter("venue");
        String status = request.getParameter("status");
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db", "aiad039", "aiad039");
            if (status.equals("2")){
            for (int i = 0; i < seats.length; i++) {
                String update = "UPDATE [schedule] SET [Seats] = [Seats] + ' " + seats[i] + "' WHERE [Venue] = " + venue + "";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(update);
                stmt.close();
            }
            for (int i = 0; i < seats.length; i++) {
                String update = "UPDATE [venue] SET [Seats] = [Seats] + ' " + seats[i] + "' WHERE [Venue] = " + venue + "";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(update);
                stmt.close();
            }}
            else{
            for (int i = 0; i < seats.length; i++) {
                String update = "UPDATE [schedule] SET [Seats] = REPLACE(Seats,'" + seats[i] + "', '') WHERE [Venue] = " + venue + "";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(update);
                stmt.close();
            }
            for (int i = 0; i < seats.length; i++) {
                String update = "UPDATE [venue] SET [Seats] = REPLACE(Seats,'" + seats[i] + "', '')  WHERE [Venue] = " + venue + "";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(update);
                stmt.close();
            }}
            if (con != null) {
                con.close();
            }
        } catch (ClassNotFoundException e) {
        } catch (SQLException e) {
        }
        this.doRetrieveEntry(request, response);
    }


    private void doShowSeat(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "/WEB-INF/SeatingPlan.jsp";
        
        if((Boolean)request.getSession().getAttribute("cargo_full")){
            address = "/WEB-INF/purfail.jsp";
            //request.setAttribute("msg","You have ");
            RequestDispatcher dispatcher = request.getRequestDispatcher(address);
            dispatcher.forward(request, response);
            
        }else{
             String sid = request.getParameter("sid");
        ScheduleLookup.ScheduleCreate();
        Schedule schedule = ScheduleLookup.getSchedule(sid);
        String check = schedule.getSeats();

        String[] taken = {""};
        if (check != null) {
            taken = schedule.getSeats().split(" ");
        }
        List<Seat> seats = new ArrayList();
        for (int i = 1; i <= 16; i++) {
            String seatid = Integer.toString(i);
            String value = "abled";
            if (Arrays.asList(taken).contains(seatid)) {
                value = "disabled";
            }
            Seat seat = new Seat(seatid, value);
            seats.add(seat);
        }
        MovieLookup.MoviesCreate();
        MovieDetail movie = MovieLookup.getMovie(schedule.getMid());
        request.setAttribute("movie", movie);
        request.setAttribute("schedule", schedule);
        request.setAttribute("seats", seats);
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
        }
       
    }

    private void doShowDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "/WEB-INF/showMovie.jsp";
        String mid = request.getParameter("mid");
        MovieLookup.MoviesCreate();
        MovieDetail movie = MovieLookup.getMovie(mid);
        request.setAttribute("movie", movie);
        List<Schedule> times = new ArrayList();
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db", "aiad039", "aiad039");
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("SELECT * FROM [schedule] WHERE [MID] ='" + mid + "'");
            ScheduleLookup.ScheduleCreate();
            while (rs != null && rs.next() != false) {
                String sid = Integer.toString(rs.getInt("SID"));
                Schedule schedule = ScheduleLookup.getSchedule(sid);
                times.add(schedule);
            }

            if (rs != null) {
                rs.close();
            }
            con.close();
        } catch (ClassNotFoundException e) {
        } catch (SQLException e) {
        }
        request.setAttribute("times", times);
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }

    private void doBuy(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "";
        String seats[] = request.getParameterValues("seat");
        String sid = request.getParameter("sid");
        float total = Float.parseFloat(request.getParameter("total"));
        String paymethod = request.getParameter("paymethod");
        String seat = "";
        
        
        // I haven't implemented any user yet
          //get the current time
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                String time = dateFormat.format(date);
        userBean = (User)request.getSession().getAttribute("user");
        int uid = userBean.getUID();
        
        String actor = userBean.getActor();
        
        if(paymethod.equalsIgnoreCase("points")){
            userBean.setPoint(-2);
            
        }
        
        if(actor.equalsIgnoreCase("customer")){
            userBean.setPoint(total/10);
            
        }
        float points = userBean.getPoint();
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db", "aiad039", "aiad039");
            for (int i = 0; i < seats.length; i++) {
                String update = "UPDATE [schedule] SET [Seats] = [Seats] + ' " + seats[i] + "' WHERE [SID] = " + sid + "";
                seat = seat + " " + seats[i];
                Statement stmt = con.createStatement();
                stmt.executeUpdate(update);
                stmt.close();

            }
            String query = "INSERT INTO [purchase] ([UID], [SID], [RID], [Status], [Seat], [Time], [Price], [GainedPoints], [PayMethod]) "
                    + "VALUES(?, ? , null, 'Success', ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);

            pstmt.setInt(1, uid);
            pstmt.setInt(2, Integer.parseInt(sid));
            pstmt.setString(3, seat);
            pstmt.setString(4, time);
            pstmt.setFloat(5, total);
            pstmt.setFloat(6, points);
            pstmt.setString(7, paymethod);
            pstmt.executeUpdate();
            con.commit();
            if (pstmt != null) {
                pstmt.close();

                address = "/WEB-INF/pursuccess.jsp";
            } else {
                address = "/WEB-INF/purfail.jsp";
            }

            if (con != null) {
                con.close();
            }
            //after successful purchase, set the cargo to be full
            if(actor.equalsIgnoreCase("customer")|| actor.equalsIgnoreCase("unregistered")){
                request.getSession().setAttribute("cargo_full",true);
            }
        } catch (ClassNotFoundException e) {
        } catch (SQLException e) {
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }

    private void doShowTicketsale(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String address = "/WEB-INF/showTicketsale.jsp";
        String seat[] = request.getParameterValues("seat");

        String sid = request.getParameter("sid");
        ScheduleLookup.ScheduleCreate();
        Schedule schedule = ScheduleLookup.getSchedule(sid);

        MovieLookup.MoviesCreate();
        MovieDetail movie = MovieLookup.getMovie(schedule.getMid());
        request.setAttribute("movie", movie);
        request.setAttribute("schedule", schedule);
        request.setAttribute("seat", seat);
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }

    private String htmlEncode(String s) {

        StringBuffer sb = new StringBuffer(s.length() * 2);

        for (int i = 0; i < s.length(); ++i) {
            char ch = s.charAt(i);
            if ((ch >= '?' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch == ' ') || (ch == '\n')) {
                sb.append(ch);
            } else {
                switch (ch) {
                    case '>':
                        sb.append("&gt;");
                        break;
                    case '<':
                        sb.append("&lt;");
                        break;
                    case '&':
                        sb.append("&amp;");
                        break;
                    case '\'':
                        sb.append("&#039;");
                        break;
                    case '"':
                        sb.append("&quot;");
                        break;
                    default:
                        sb.append("&#");
                        sb.append(new Integer(ch).toString());
                        sb.append(';');
                }
            }
        }

        return sb.toString();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
