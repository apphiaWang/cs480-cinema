package cs4280;

/**
 *
 * @author jsvollmer2
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class homeController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User userBean = (User) session.getAttribute("user");
        try{
            if(userBean.getActor().equals("manager")){
                this.showManagerHome(request, response);
            }else if(userBean.getActor().equals("officer")){
                this.showOfficerHome(request, response);
            }else{
            this.showCustomerHome(request, response);
        }
        }catch(NullPointerException e){
            
        }finally{
            
        }
    }
private void showCustomerHome(HttpServletRequest request, HttpServletResponse response) throws IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            User userBean = (User) session.getAttribute("user");
            
            //session.invalidate();
            out.println("<html>");
            out.println("<head>");
            out.println(" <title>Home Page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Home Page</h1>");
            out.println("<fieldset>");
            out.println("<p>Welcome! Dear "
                    +userBean.getName() +"</p>");
            
            
            
            //print all purchase record
                out.println("<fieldset>");
                out.println("<legend>Purchase Record</legend>");
                
                // make connection to db and retrieve data from the table			
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db",
                                "aiad039", "aiad039");
                Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                
                ResultSet rs = stmt.executeQuery("SELECT * FROM [purchase] WHERE [uid]="+userBean.getUID());
                
                //print all purchase record
                out.println("<div><table style='width:100%'>");
                out.println("<thead>");
                out.println("<th align='left'>Purchas ID</th><th align='left'>Movie</th><th align='left'>Purchase Date</th><th align='left'>Action</th>");
                out.println("</thead>");
                out.println("<tbody>");
                
                int numRow = 0;
                if (rs != null && rs.last() != false) {
                    numRow = rs.getRow();
                    rs.beforeFirst();
                }
               
                if(numRow == 0){//if there is no record
                    out.println("<h3>You have no purchase record. <a href = ''>Go to buy ticket.</a></h3>");
                }else{
                    while (rs != null && rs.next() != false) {
                        int pid = rs.getInt("pid");
                        int sid = rs.getInt("sid");
                        String date = rs.getString("time");



                        out.println("<tr>");
                        out.println("<td>" + pid + "</td>");
                        out.println("<td>" + sid + "</td>");
                        out.println("<td>" + date + "</td>");

                        out.println("<td>");
                        out.println("<a href='" + request.getRequestURI() + "?action=refund&pid=" + pid + "'>Refund</a>");
                        out.println("</td>");
                        out.println("</tr>");

                    }
                    out.println("</fieldset>");
                }
                    
                
                
                  //get the current time
//                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//                Date date = new Date();
//                String d = dateFormat.format(date);
            out.println("</fieldset>");
            

            out.println("</body>");
            out.println("</html>");
            
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (con != null) {
                con.close();
            }
            
        } catch (ClassNotFoundException e) {
                out.println("<div style='color: red'>" + e.toString() + "</div>");
         } catch (SQLException e) {
                out.println("<div style='color: red'>" + e.toString() + "</div>");
         } finally { 
            
            out.close();
        }
      
    }

    private void showManagerHome(HttpServletRequest request, HttpServletResponse response) throws IOException, NullPointerException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        
        try {
            HttpSession session = request.getSession();
            User userBean = (User) session.getAttribute("user");
            
            //session.invalidate();
            out.println("<html>");
            out.println("<head>");
            out.println(" <title>Home Page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Home Page</h1>");
            out.println("<fieldset>");
            out.println("<p>Welcome! Dear "
                    +userBean.getName() +"</p>");
            
            
            
            //print all purchase record
                out.println("<fieldset>");
                out.println("<legend>Manipulation</legend>");
                out.println("<a href='" + request.getRequestURI() + "?action=manageSeats'>Mange Seats</a>");
                out.println("<br><a href='" + request.getRequestURI() + "?action=scheduleMovie'>Manage Movie Schedule</a>");
                out.println("</fieldset>");
                
                  //get the current time
//                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//                Date date = new Date();
//                String d = dateFormat.format(date);
            out.println("</fieldset>");

        } finally { 
            
            out.close();
        }
    }

    private void showOfficerHome(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        
        try {
            HttpSession session = request.getSession();
            User userBean = (User) session.getAttribute("user");
            
            //session.invalidate();
            out.println("<html>");
            out.println("<head>");
            out.println(" <title>Home Page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Home Page</h1>");
            out.println("<fieldset>");
            out.println("<p>Welcome! Dear "
                    +userBean.getName() +"</p>");
            
            
            
            //print all purchase record
                out.println("<fieldset>");
                out.println("<legend>Request of refunds</legend>");
                
                // make connection to db and retrieve data from the table			
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection("jdbc:sqlserver://w2ksa.cs.cityu.edu.hk:1433;databaseName=aiad039_db",
                                "aiad039", "aiad039");
                Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                
                ResultSet rs = stmt.executeQuery("SELECT * FROM [request] ");
                
                //print all purchase record
                out.println("<div><table style='width:100%'>");
                out.println("<thead>");
                out.println("<th align='left'>Request ID</th><th align='left'>Purchase</th><th align='left'>Status</th><th align='left'>Action</th>");
                out.println("</thead>");
                out.println("<tbody>");
                
                int numRow = 0;
                if (rs != null && rs.last() != false) {
                    numRow = rs.getRow();
                    rs.beforeFirst();
                }
               
                if(numRow == 0){//if there is no record
                    out.println("<h3>You have no purchase record. <a href = ''>Go to buy ticket.</a></h3>");
                }else{
                    while (rs != null && rs.next() != false) {
                        int rid = rs.getInt("rid");
                        int pid = rs.getInt("pid");
                        String status = rs.getString("status");
                        out.println("<tr>");
                        out.println("<td>" + rid + "</td>");
                        out.println("<td>" + pid + "</td>");
                        out.println("<td>" + status + "</td>");
                        out.println("<td>");
                        out.println("<a href='" + request.getRequestURI() + "?action=authorize&rid=" + rid + "'>process</a>");
                        out.println("</td>");
                        out.println("</tr>");

                    }
                    out.println("</fieldset>");
                }
                    
                
                
                  //get the current time
//                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//                Date date = new Date();
//                String d = dateFormat.format(date);
            out.println("</fieldset>");
            

            out.println("</body>");
            out.println("</html>");
            
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (con != null) {
                con.close();
            }
            
        } catch (ClassNotFoundException e) {
                out.println("<div style='color: red'>" + e.toString() + "</div>");
         } catch (SQLException e) {
                out.println("<div style='color: red'>" + e.toString() + "</div>");
         } finally { 
            
            out.close();
        }
      
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    

   

}
