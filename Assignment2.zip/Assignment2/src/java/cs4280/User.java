/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs4280;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
/**
 *
 * @author yanfewang3
 */
public class User {
    private int uid;
    private ArrayList<PurchaseRec> record = new ArrayList<>();
    private float point = -1;
    private String name, actor;
    
    public User(){
        uid = 99;
        name = "unknown";
        actor = "unregistered";
        point = -1;

    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String n){
        name = n;
    }
    public int getUID(){
        return uid;
    }
    
    public void setUID(int id){
        uid = id;
    }
    
    public String getActor(){
        return actor;
    }
    
    public void setActor(String a){
        actor = a;
    }
    public ArrayList<PurchaseRec> getRecord(){
        return record;
    }
    
    public void setRecord(String r){
        PurchaseRec rec = new PurchaseRec();
        
        record.add(rec);
    }
    
    public float getPoint(){
        return point;
    }
    
    public void setPoint(float p){
        point += p;
    }
    
    public String showInfo(){
        String info = "Welcome dear ";
        info += name+", ";
        if(actor.equals("customer")){
            info+="you have "+ point+" loyalty points";
        }
        return info;
    }
}
